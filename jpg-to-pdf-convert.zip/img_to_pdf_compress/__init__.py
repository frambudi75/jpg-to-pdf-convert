# img_to_pdf_compress/__init__.py

__version__ = "4.0.0"

# Optional: expose fungsi utama kalau ada
# from .main import convert_images_to_pdf
